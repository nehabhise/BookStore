const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')

const app = express();
app.use(cors())
app.use(express.json())

const PORT = process.env.PORT || 8080;

// Define book schema
const bookSchema = new mongoose.Schema({
    title:  String,
    author: String,
    genre:  String,
    
  },{
    timestamps:true
  });

// Define Book model
const Book = mongoose.model('Book', bookSchema);

// app.get("/",(req,res)=>{
//     res.json({message:"Server is up"});
// })
// Get all books
app.get('/', async (req, res) => {
    try {
      const books = await Book.find();
      res.json(books);
    } catch (err) {
      console.error('Error fetching data:', err);
      res.status(500).json({ message: 'Internal Server Error' });
    }
  });

// Create a new book
app.post('/create', async (req, res) => {
    console.log(req.body)
    const data= new Book(req.body)
    await data.save()
    res.send({success:true,message:"data save successfully"})
  });

// // update 
// app.put('/update',async(req,res)=>{
//     console.log(req.body)
     
//     const data = Book.updateOne({_id:req.body._id},{title:'',author:'',genre:''})
//     console.log("Data:",data)
//     res.send({sucess:true,message:"data updated successfully"}
// )
// })

// update 
app.put('/update', async (req, res) => {
  try {
      const { _id, title, author, genre } = req.body;

      // Update the book using updateOne
      const updatedBook = await Book.updateOne({ _id }, { title, author, genre });
      console.log("UpdatedBook",updatedBook)
      console.log("UpdatedBook.nModified",updatedBook.nModified)


     // if (updatedBook.nModified > 0 ) {
      if(updatedBook.modifiedCount > 0 && updatedBook.matchedCount > 0){
          // Book updated successfully
          res.json({ success: true, message: "Data updated successfully" });
      } else {
          // No matching book found
          res.status(404).json({ success: false, message: "Book not found" });
      }
  } catch (error) {
      console.error('Error updating book:', error);
      res.status(500).json({ success: false, message: "Internal Server Error" });
  }
});


// app.delete("/delete/:id",async(req,res)=>{
//   const id = req.params.id
//   console.log(req.params.id)
//   const data = await Book.deleteOne({_id:id})
//   res.send({sucess:true,message:"data deleted successfully"})

// })
app.delete("/delete/:id", async(req, res) => {
  try {
    console.log("params",req.params)
    const  id  = req.params.id;
    console.log("Deleting book with ID:", id);
    const result = await Book.deleteOne({ _id: id });
    if (result.deletedCount === 1) {
        console.log("Book deleted successfully");
        res.json({ success: true, message: "Book deleted successfully" });
    } else {
        console.log("No book found with ID:", id);
        res.status(404).json({ success: false, message: "Book not found" });
    }
} catch (error) {
    console.error("Error deleting book:", error);
    res.status(500).json({ success: false, message: "Internal Server Error" });
}
});

mongoose.connect('mongodb://localhost:27017/BooksDB')
  .then(() => {
    console.log('MongoDB connected')
    app.listen(PORT,()=>console.log("Server is running"))
})
  .catch(err => {
    console.error('MongoDB connection error:', err);
  });


