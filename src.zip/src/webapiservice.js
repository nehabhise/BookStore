import axios from "axios";
import "./http-interceptor";
//const httpInterceptor = new HttpInterceptor();
const API_URL = "https://localhost:5000/"
//const API_URL =  process.env.REACT_APP_API_URL;
  export const GetStandaloneToken = (login) => {
    return axios.post(API_URL+"Authorization/GetStandaloneToken", login)
  }
  
  export const GenerateEmailForAuthentication = (login) => {
    return axios.post(API_URL+"Authorization/GenerateEmailForAuthentication", login)
  }