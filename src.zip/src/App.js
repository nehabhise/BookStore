import './App.css';
import Book from './book';

function App() {
  return (
    <div>
    {/* Your component JSX goes here */}
    {/* <h1>Hello from App!</h1> */}
    <Book /> {/* Call MyComponent here */}
</div>
   
  );
}

export default App;
