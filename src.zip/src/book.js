// Book.js
import React, { Component } from 'react';
import axios from 'axios';
import { FaTrashAlt, FaEdit, FaArrowLeft, FaArrowRight,FaPlusCircle } from 'react-icons/fa';
// import '../../bookdetails/src/book.css';
import  backgroundImg from '../../bookdetails/src/assets/images/Background_7.jpg';
// import editicon from '../../bookdetails/src/assets/images/edit-icon.png';
import editicon from '../../bookdetails/src/assets/images/pencil-square.svg';


axios.defaults.baseURL = "http://localhost:8080/";

class Book extends Component {
    constructor(props) {
        super(props);
        this.state = {
            books: [],
            showModal: false,
            editModal: false,
            newBook: {
                title: '',
                author: '',
                genre: ''
            },
            currentPage: 1,
            booksPerPage: 5
        };
    }

    componentDidMount() {
        this.handleDisplay();
    }

    handleModal = () => {
        this.setState({ showModal: true });
    }

    handleCloseModal = () => {
        this.setState({
            newBook: {
                _id: '',
                title: '',
                author: '',
                genre: ''
            }
        });
        this.setState({ showModal: false });
        this.setState({ editModal: false });
    }

    handleInputChange = (event) => {
        const { name, value } = event.target;
        this.setState(prevState => ({
            newBook: {
                ...prevState.newBook,
                [name]: value
            }
        }));
    }

    handleDisplay = () => {
        axios.get('/')
            .then(response => {
                this.setState({ books: response.data });
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }

    handleAddBook = () => {
        console.log("Newbook",this.state.newBook)
        const { _id, ...newBookData } = this.state.newBook;

        console.log("Newbook", newBookData);
        axios.post('/create', newBookData)
            .then(response => {
                console.log("Book added successfully:", response.data);
                alert("Record Added successfully")

                this.handleDisplay();
            })
            .catch(error => {
                console.error('Error adding book:', error);
            });

        this.handleCloseModal();
    }

    handleEditBook = () => {
        const { newBook } = this.state;
        axios.put('update', newBook)
            .then(response => {
                console.log("Book updated successfully:", response.data);
                alert("Record updated successfully")

                this.setState(prevState => ({
                    books: prevState.books.map(book =>
                        book._id === newBook._id ? { ...book, ...newBook } : book
                    )
                }));
                this.handleCloseModal();
            })
            .catch(error => {
                console.error('Error updating book:', error);
            });
    }

    handleDelete = (bookId) => {
        axios.delete('/delete/' + bookId)
            .then(response => {
                console.log("Book deleted successfully:", response.data);
                this.handleDisplay();
                alert("Record deleted successfully")

            })
            .catch(error => {
                console.error('Error deleting book:', error);
            });
    }

    handleEdit = (bookId) => {
        const bookToEdit = this.state.books.find(book => book._id === bookId);
        if (bookToEdit) {
            this.setState({
                newBook: {
                    _id: bookToEdit._id,
                    title: bookToEdit.title,
                    author: bookToEdit.author,
                    genre: bookToEdit.genre
                }
            });
            this.setState({ editModal: true });
        } else {
            console.error('Book not found for editing.');
        }
    }

    render() {
        const { books, currentPage, booksPerPage } = this.state;
        const indexOfLastBook = currentPage * booksPerPage;
        const indexOfFirstBook = indexOfLastBook - booksPerPage;
        const currentBooks = books.slice(indexOfFirstBook, indexOfLastBook);
        const totalPages = Math.ceil(books.length / booksPerPage);

        return (
            <div className="book-container">
                <h1 className="book-heading">Welcome To Book Store</h1>
                <div className="add-book-icon" onClick={this.handleModal}>
                    <FaPlusCircle className="add-icon" />
                </div>
                <table className="book-table">
                    <thead>
                        <tr>
                            {/* <th>Sr No.</th> */}
                            <th style={{fontSize:'15px'}}>Book Title</th>
                            <th style={{fontSize:'15px'}}>Book Author</th>
                            <th style={{fontSize:'15px'}}>Book Genre</th>
                            {/* <th>Delete</th>
                            <th>Update</th> */}
                        </tr>
                    </thead>
                    <tbody>
                        {currentBooks.map((book, index) => (
                            <tr key={index}>
                                {/* <td>{index + 1}</td> */}
                                <td>{book.title}</td>
                                <td>{book.author}</td>
                                <td>{book.genre}</td>
                                <td>
                                    {/* <button onClick={() => this.handleDelete(book._id)}>
                                        <FaTrashAlt />
                                    </button> */}
                                    <button className="book-button" onClick={() => this.handleDelete(book._id)}>
                                        Delete
                                    </button>
                                </td>
                                <td>
                                    <button  className="book-button" onClick={() => this.handleEdit(book._id)}>
                                        {/* <FaEdit /> */}
                                        Edit
                                    </button>
                                    {/* <a  onClick={() => this.handleEdit(book._id)}>Edit</a> */}
                                    {/* <button onClick={() => this.handleEdit(book._id)}>
                                    <img className="icon-edit" src={editicon} alt="Edit" /> 
                                </button> */}
                                    
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {/* <div className="book-actions">
                    <button className="book-button" onClick={this.handleModal}>Add Book</button>
                </div> */}
                {totalPages > 1 && (
                    <div className="pagination">
                        <button onClick={() => this.setState({ currentPage: currentPage - 1 })} disabled={currentPage === 1}><FaArrowLeft /></button>
                        <span>{currentPage} of {totalPages}</span>
                        <button onClick={() => this.setState({ currentPage: currentPage + 1 })} disabled={currentPage === totalPages}><FaArrowRight /></button>
                    </div>
                )}
                {this.state.showModal && (
                    <div className="custom-modal">
                        <div className="custom-modal-content">
                            <span className="addbook-title"> Add a new Book </span>
                            <span onClick={this.handleCloseModal} className="custom-close">&times;</span>
                            <div className="input-group">
                                <label htmlFor="book-title">Book Title:</label>
                                <input
                                    type="text"
                                    id="book-title"
                                    name="title"
                                    value={this.state.newBook.title}
                                    onChange={this.handleInputChange}
                                    placeholder='Enter book Title'
                                />
                            </div>
                            <div className="input-group">
                                <label htmlFor="book-author">Book Author:</label>
                                <input
                                    type="text"
                                    id="book-author"
                                    name="author"
                                    value={this.state.newBook.author}
                                    onChange={this.handleInputChange}
                                    placeholder='Enter book Author'
                                />
                            </div>
                            <div className="input-group">
                                <label htmlFor="book-genre">Book Genre:</label>
                                <input
                                    type="text"
                                    id="book-genre"
                                    name="genre"
                                    value={this.state.newBook.genre}
                                    onChange={this.handleInputChange}
                                    placeholder='Enter book Genre'
                                />
                            </div>
                            <button className="custom-button" onClick={this.handleAddBook}>Add Book</button>
                        </div>
                    </div>
                    
                )}
                {this.state.editModal && (
                    <div className="custom-modal">
                        <div className="custom-modal-content">
                        <span className="addbook-title"> Update Book Details </span>

                            <span onClick={this.handleCloseModal} className="custom-close">&times;</span>
                            <div className="input-group">
                                <label htmlFor="book-title">Book Title:</label>
                                <input
                                    type="text"
                                    id="book-title"
                                    name="title"
                                    value={this.state.newBook.title}
                                    onChange={this.handleInputChange}
                                    placeholder='Enter Book Title'
                                />
                            </div>
                            <div className="input-group">
                                <label htmlFor="book-author">Book Author:</label>
                                <input
                                    type="text"
                                    id="book-author"
                                    name="author"
                                    value={this.state.newBook.author}
                                    onChange={this.handleInputChange}
                                    placeholder='Enter Book Author'
                                />
                            </div>
                            <div className="input-group">
                                <label htmlFor="book-genre">Book Genre:</label>
                                <input
                                    type="text"
                                    id="book-genre"
                                    name="genre"
                                    value={this.state.newBook.genre}
                                    onChange={this.handleInputChange}
                                    placeholder='Enter book Genre'
                                    
                                />
                            </div>
                            <button className="custom-button" onClick={this.handleEditBook}>Edit Book</button>
                        </div>
                    </div>
                )}
            </div>
        );
    }
}

export default Book;

//------------------pagination code--------------------------
// import React, { Component } from 'react';
// import axios from 'axios';
// import { FaTrashAlt, FaEdit } from 'react-icons/fa';

// axios.defaults.baseURL = "http://localhost:8080/";

// class Book extends Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//             books: [],
//             showModal: false,
//             editModal: false,
//             newBook: {
//                 title: '',
//                 author: '',
//                 genre: ''
//             },
//             currentPage: 1,
//             booksPerPage: 2
//         };
//     }

//     componentDidMount() {
//         this.handleDisplay();
//     }

//     handleModal = () => {
//         this.setState({ showModal: true });
//     }

//     handleCloseModal = () => {
//         this.setState({ showModal: false });
//         this.setState({ editModal: false });
//     }

//     handleInputChange = (event) => {
//         const { name, value } = event.target;
//         this.setState(prevState => ({
//             newBook: {
//                 ...prevState.newBook,
//                 [name]: value
//             }
//         }));
//     }

//     handleDisplay = () => {
//         axios.get('/')
//             .then(response => {
//                 this.setState({ 
//                     books: response.data,
//                     currentPage: 1  // Reset current page to 1 after fetching new data
//                 });
//             })
//             .catch(error => {
//                 console.error('Error fetching data:', error);
//             });
//     }

//     handleAddBook = () => {
//         axios.post('/create', this.state.newBook)
//             .then(response => {
//                 console.log("Book added successfully:", response.data);
//                 this.handleDisplay();
//             })
//             .catch(error => {
//                 console.error('Error adding book:', error);
//             });

//         this.handleCloseModal();
//     }

//     handleEditBook = () => {
//         const { newBook } = this.state;

//         axios.put('update', newBook)
//             .then(response => {
//                 console.log("Book updated successfully:", response.data);
//                 this.setState(prevState => ({
//                     books: prevState.books.map(book =>
//                         book._id === newBook._id ? { ...book, ...newBook } : book
//                     )
//                 }));
//                 this.handleCloseModal();
//             })
//             .catch(error => {
//                 console.error('Error updating book:', error);
//             });
//     }

//     handleDelete = (bookId) => {
//         axios.delete('/delete/' + bookId)
//             .then(response => {
//                 console.log("Book deleted successfully:", response.data);
//                 this.setState(prevState => ({
//                     books: prevState.books.filter(book => book.id !== bookId)
//                 }));
//                 this.handleDisplay();
//             })
//             .catch(error => {
//                 console.error('Error deleting book:', error);
//             });
//     }

//     handleEdit = (bookId) => {
//         const bookToEdit = this.state.books.find(book => book._id === bookId);

//         if (bookToEdit) {
//             this.setState({
//                 newBook: {
//                     _id: bookToEdit._id,
//                     title: bookToEdit.title,
//                     author: bookToEdit.author,
//                     genre: bookToEdit.genre
//                 }
//             });
//             this.setState({ editModal: true });
//         } else {
//             console.error('Book not found for editing.');
//         }
//     }

//     render() {
//         const { books, currentPage, booksPerPage } = this.state;
//         const indexOfLastBook = currentPage * booksPerPage;
//         const indexOfFirstBook = indexOfLastBook - booksPerPage;
//         const currentBooks = books.slice(indexOfFirstBook, indexOfLastBook);

//         const totalBooks = books.length;
//         const totalPages = Math.ceil(totalBooks / booksPerPage);

//         return (
//             <div>
//                 <div className="c-book">
//                     <div className="container">
//                         <h1>Welcome To Book Store</h1>
//                         <div style={{ float: 'right' }}>
//                             <a href="javascript:void(0)" className="o-secondary-button c-modal-btn" aria-label="click here to add " data-modal="addbook" style={{ paddingRight: "25px" }} onClick={() => { this.handleModal() }}> Add Book</a>
//                         </div>

//                         <div style={{ paddingTop: "50px", paddingLeft: "20px" }}>
//                             {books.length > 0 && (
//                                 <table className="book-table__table">
//                                     <thead className="book-table__head">
//                                         <tr className="book-table__headrow">
//                                             <th className="book-table__headcell">Sr No.</th>
//                                             <th className="book-table__headcell">Book Title</th>
//                                             <th className="book-table__headcell">Book Author</th>
//                                             <th className="book-table__headcell">Book Genre</th>
//                                             <th className="book-table__headcell">Delete</th>
//                                             <th className="book-table__headcell">Update</th>
//                                         </tr>
//                                     </thead>
//                                     <tbody className="book-table__datarow">
//                                         {currentBooks.map((book, index) => (
//                                             <tr className="book-table__titlerow" key={index}>
//                                                 <td className="book-table__datacell">{indexOfFirstBook + index + 1}</td>
//                                                 <td className="book-table__datacell">{book.title}</td>
//                                                 <td className="book-table__datacell">{book.author}</td>
//                                                 <td className="book-table__datacell">{book.genre}</td>
//                                                 <td className="book-table__datacell">
//                                                     <button onClick={() => this.handleDelete(book._id)}>
//                                                         <FaTrashAlt />
//                                                     </button>
//                                                 </td>
//                                                 <td className="book-table__datacell">
//                                                     <button onClick={() => this.handleEdit(book._id)}>
//                                                         <FaEdit />
//                                                     </button>
//                                                 </td>
//                                             </tr>
//                                         ))}
//                                     </tbody>
//                                 </table>
//                             )}

//                             {totalPages > 1 && (
//                                 <div>
//                                     <button 
//                                         onClick={() => this.setState({ currentPage: currentPage - 1 })} 
//                                         disabled={currentPage === 1}
//                                     >
//                                         Previous
//                                     </button>
//                                     <span>{currentPage}</span>
//                                     <button 
//                                         onClick={() => this.setState({ currentPage: currentPage + 1 })} 
//                                         disabled={currentPage === totalPages}
//                                     >
//                                         Next
//                                     </button>
//                                 </div>
//                             )}
//                         </div>
//                     </div>
//                 </div>
//             </div>
//         );
//     }
// }

// export default Book;




// import React, { Component ,useState, useEffect} from 'react';
// import axios from 'axios';
// import { FaTrashAlt, FaEdit } from 'react-icons/fa';

// axios.defaults.baseURL = "http://localhost:8080/"
// class Book extends Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//             books: [],
//             showModal: false,
//             editModal: false,
//             newBook: {
                
//                 title: '',
//                 author: '',
//                 genre: ''
//             },
//             currentPage: 1,
//             booksPerPage: 2
//         };
//     }
//     componentDidMount() {
//         this.handleDisplay()
//     }
//     handleModal = () => {
//         this.setState({ showModal: true });
//     }

//     handleCloseModal = () => {
//         this.setState({ showModal: false });
//         this.setState({ editModal: false });

//     }
//     handleInputChange = (event) => {
//         const { name, value } = event.target;
//         this.setState(prevState => ({
//             newBook: {
//                 ...prevState.newBook,
//                 [name]: value
//             }
//         }));
//     }
//     handleDisplay = () => {
//         // Fetch data from the server when the component mounts
//         // axios.get('/')
//         //     .then(response => {

//         //         this.setState({ books: response.data }); // Update state with fetched books
//         //         console.log("After api call", this.state.books)
//         //     })
//         //     .catch(error => {
//         //         console.error('Error fetching data:', error);
//         //     });
//         axios.get('/').then(response => {
//             this.setState({ 
//                 books: response.data,
//                 currentPage: 1  // Reset current page to 1 after fetching new data
//             }); // Update state with fetched books
//             console.log("After api call", this.state.books);
//         })
//         .catch(error => {
//             console.error('Error fetching data:', error);
//         });
//     }
//     handleAddBook = () => {
//         // Here you can access the new book details from this.state.newBook
//         console.log("New Book Details:", this.state.newBook);

//         // Add code to send new book details to server or perform any other operation
//         // For example:
//         axios.post('/create', this.state.newBook)
//             .then(response => {
//                 console.log("Book added successfully:", response.data);
//                 this.handleDisplay()
//             })
//             .catch(error => {
//                 console.error('Error adding book:', error);
//             });

//         // After adding the book, you may want to close the modal
//         this.handleCloseModal();
//     }

//     handleEditBook = () => {
//         const { newBook } = this.state;
        
//         // Make an API call to update the book details
//         axios.put('update', newBook)
        
//             .then(response => {
//                 console.log("Book updated successfully:", response.data);
//                 // Update the state to reflect the changes
//                 this.setState(prevState => ({
//                     books: prevState.books.map(book =>
//                         book._id === newBook._id ? { ...book, ...newBook } : book
//                     )
//                 }));
//                 console.log("book:",newBook)
//                 // Close the modal
//                 this.handleCloseModal();
//             })
//             .catch(error => {
//                 console.error('Error updating book:', error);
//             });

//     }

//     // handleEditBook = () => {
//     //     const { newBook } = this.state;
    
//     //     // Make a PUT request to update the book details
//     //     axios.put(`/update/${newBook._id}`, newBook) // Pass the book ID as part of the URL
//     //         .then(response => {
//     //             console.log("Book updated successfully:", response.data);
//     //             // Update the state to reflect the changes
//     //             this.setState(prevState => ({
//     //                 books: prevState.books.map(book =>
//     //                     book._id === newBook._id ? { ...book, ...newBook } : book
//     //                 )
//     //             }));
//     //             // Close the modal
//     //             this.handleCloseModal();
//     //         })
//     //         .catch(error => {
//     //             console.error('Error updating book:', error);
//     //             // Handle error
//     //         });
//     // };
    
    
//     // Outside the render method
//     handleDelete = (bookId) => {
//         console.log("bookid", bookId)
//         // Make an API call to delete the book with the specified ID
//         axios.delete('/delete/' + bookId)
//             .then(response => {
//                 console.log("Book deleted successfully:", response.data);
//                 // Update the state to remove the deleted book from the list
//                 this.setState(prevState => ({
//                     books: prevState.books.filter(book => book.id !== bookId)
//                 }));
//                 this.handleDisplay()
//             })
//             .catch(error => {
//                 console.error('Error deleting book:', error);
//             });
//     }

//     handleEdit = (bookId) => {
//         // Find the book with the specified ID
//         const bookToEdit = this.state.books.find(book => book._id === bookId);

//         // Check if the book is found
//         if (bookToEdit) {
//             // Set the newBook state with the book's details
//             this.setState({
//                 newBook: {
//                     _id:bookToEdit._id,
//                     title: bookToEdit.title,
//                     author: bookToEdit.author,
//                     genre: bookToEdit.genre
//                 }
//             });

//             // Open the modal to edit the book
//             this.setState({ editModal: true });
//         } else {
//             console.error('Book not found for editing.');
//         }
//     }

//     render() {
//         const { books, currentPage, booksPerPage } = this.state;

//         // Calculate index range for books to display
//         const indexOfLastBook = currentPage * booksPerPage;
//         const indexOfFirstBook = indexOfLastBook - booksPerPage;
//         const currentBooks = books.slice(indexOfFirstBook, indexOfLastBook);
//         return (
//             <div>
//                 <div className="c-book">
//                     <div className="container">

//                         {/* Your component JSX goes here */}
//                         <h1>Welcome To Book Store</h1>
//                         <div style={{ float: 'right' }}>
//                             <a href="javascript:void(0)" className="o-secondary-button c-modal-btn" aria-label="click here to add " data-modal="addbook" style={{ paddingRight: "25px" }} onClick={() => { this.handleModal() }}> Add Book</a>

//                             {/* <a href="javascript:void(0)" className="o-secondary-button c-modal-btn" aria-label="click here to update " data-modal="updatebook" style={{paddingLeft:"20px",paddingRight:"20px"}}> Update Book</a> */}
//                         </div>

//                         <div style={{ paddingTop: "50px", paddingLeft: "20px" }}>

//                             <table className="book-table__table">
//                                 <thead className="book-table__head">
//                                     <tr className="book-table__headrow">
//                                         <th className="book-table__headcell">Sr No.</th>
//                                         <th className="book-table__headcell">Book Title</th>
//                                         <th className="book-table__headcell">Book Author</th>
//                                         <th className="book-table__headcell">Book Genre</th>
//                                         <th className="book-table__headcell">Delete</th>
//                                         <th className="book-table__headcell">Update</th>

//                                     </tr>
//                                 </thead>
//                                 {this.state.books.length > 0 && (
//                                     <tbody className="book-table__datarow">
//                                         {this.state.books.map((book, index) => (
//                                             <tr className="book-table__titlerow" key={index}>
//                                                 <td className="book-table__datacell">{index + 1}</td>
//                                                 <td className="book-table__datacell">{book.title}</td>
//                                                 <td className="book-table__datacell">{book.author}</td>
//                                                 <td className="book-table__datacell">{book.genre}</td>
//                                                 <td className="book-table__datacell">
//                                                     <button onClick={() => this.handleDelete(book._id)}>
//                                                         <FaTrashAlt />
//                                                     </button>
//                                                 </td>
//                                                 <td className="book-table__datacell">
//                                                     <button onClick={() => this.handleEdit(book._id)}>
//                                                         <FaEdit />
//                                                     </button>
//                                                 </td>
//                                             </tr>
//                                         ))}
//                                     </tbody>
//                                 )}
//                             </table>

//                             {/* Pagination controls */}
//                             {this.state.books.length > 0 && (
//         <div>
//             <button onClick={() => this.setState({ currentPage: currentPage - 1 })}>Previous</button>
//             <span>{currentPage}</span>
//             <button onClick={() => this.setState({ currentPage: currentPage + 1 })}>Next</button>
//         </div>
//     )}
//                         </div>

//                     </div>

//                 </div>
//                 {/* Add book Modal Popup ------ START */}


//                 {/* Modal content */}
//                 {this.state.showModal && (
//                     <div className="custom-modal">
//                         <div className="custom-modal-content">
//                             <span onClick={this.handleCloseModal} className="custom-close">&times;</span>
//                             <div className="input-group">
//                                 <label htmlFor="book-title">Book Title:</label>
//                                 <input
//                                     type="text"
//                                     id="book-title"
//                                     name="title"
//                                     value={this.state.newBook.title}
//                                     onChange={this.handleInputChange}
//                                 />
//                             </div>
//                             <div className="input-group">
//                                 <label htmlFor="book-author">Book Author:</label>
//                                 <input
//                                     type="text"
//                                     id="book-author"
//                                     name="author"
//                                     value={this.state.newBook.author}
//                                     onChange={this.handleInputChange}
//                                 />
//                             </div>
//                             <div className="input-group">
//                                 <label htmlFor="book-genre">Book Genre:</label>
//                                 <input
//                                     type="text"
//                                     id="book-genre"
//                                     name="genre"
//                                     value={this.state.newBook.genre}
//                                     onChange={this.handleInputChange}
//                                 />
//                             </div>
//                             <button className="custom-button" onClick={this.handleAddBook}>Add Book</button>
//                         </div>
//                     </div>
//                 )}

//                 {this.state.editModal && (
//                     <div className="custom-modal">
//                         <div className="custom-modal-content">
//                             <span onClick={this.handleCloseModal} className="custom-close">&times;</span>
//                             <div className="input-group">
//                                 <label htmlFor="book-title">Book Title:</label>
//                                 <input
//                                     type="text"
//                                     id="book-title"
//                                     name="title"
//                                     value={this.state.newBook.title}
//                                     onChange={this.handleInputChange}
//                                 />
//                             </div>
//                             <div className="input-group">
//                                 <label htmlFor="book-author">Book Author:</label>
//                                 <input
//                                     type="text"
//                                     id="book-author"
//                                     name="author"
//                                     value={this.state.newBook.author}
//                                     onChange={this.handleInputChange}
//                                 />
//                             </div>
//                             <div className="input-group">
//                                 <label htmlFor="book-genre">Book Genre:</label>
//                                 <input
//                                     type="text"
//                                     id="book-genre"
//                                     name="genre"
//                                     value={this.state.newBook.genre}
//                                     onChange={this.handleInputChange}
//                                 />
//                             </div>
//                             <button className="custom-button" onClick={this.handleEditBook}>Edit Book</button>
//                         </div>
//                     </div>
//                 )}

//                 {/* Add book Modal Popup ------ END */}
//             </div>
//         );
//     }
// }

// export default Book;
